public abstract class PizzaDec implements Pizza {
    protected Pizza tempPizza;
    public PizzaDec(Pizza newpizza){
        this.tempPizza = newpizza;
    }
    @Override
    public String getDescription(){
        return tempPizza.getDescription();
    }
    @Override
    public double getCost() {
        return tempPizza.getCost();
    }
}
