public class JetpackStrategy implements MovementStrategy{
    @Override
    public void move() {
        System.out.println("Flying with a Jetpack at 60 km/h");
    }
}
