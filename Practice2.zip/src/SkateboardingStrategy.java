public class SkateboardingStrategy implements MovementStrategy{
    @Override
    public void move() {
        System.out.println("Skateboarding at 15 km/h");
    }
}
