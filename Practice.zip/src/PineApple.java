public class PineApple extends PizzaDec {
    public PineApple(Pizza newPizza) {
        super(newPizza);
    }
    @Override
    public String getDescription() {
        return tempPizza.getDescription() + ", PineApple";
    }
    @Override
    public double getCost() {
        return tempPizza.getCost() + 1.5;
    }
}