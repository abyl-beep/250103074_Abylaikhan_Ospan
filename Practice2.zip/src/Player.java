public class Player {
    public MovementStrategy movementStrategy;
    public Player(MovementStrategy movementStrategy) {
        this.movementStrategy = movementStrategy;
    }
    public void setMovementStrategy(MovementStrategy movementStrategy) {
        this.movementStrategy = movementStrategy;
    }
    public void move() {
        movementStrategy.move();
    }
}
