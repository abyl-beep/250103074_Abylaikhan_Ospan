public class Cheese extends PizzaDec {
    public Cheese(Pizza newPizza) {
        super(newPizza);
    }
    @Override
    public String getDescription() {
        return tempPizza.getDescription() + ", Cheese";
    }
    @Override
    public double getCost() {
        return tempPizza.getCost() + 2.0;
    }
}