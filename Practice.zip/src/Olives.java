public class Olives extends PizzaDec {
    public Olives(Pizza newPizza) {
        super(newPizza);
    }
    @Override
    public String getDescription() {
        return tempPizza.getDescription() + ", Olives";
    }
    @Override
    public double getCost() {
        return tempPizza.getCost() + 1.0;
    }
}