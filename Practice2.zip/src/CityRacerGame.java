public class CityRacerGame {
    public static void main(String[] args) {
        Player player = new Player(new WalkingStrategy());

        System.out.println("Starting the race:");
        player.move();
        System.out.println("\nSwitched to skateboard!");
        player.setMovementStrategy(new SkateboardingStrategy());
        player.move();

        System.out.println("\nSwitched to Jetpack mid-run!");
        player.setMovementStrategy(new JetpackStrategy());
        player.move();
    }
}